#ifndef _E_EXP_H_
#define	_E_EXP_H_

double __ieee754_exp(double x);
double __ieee754_log(double x);

#endif
